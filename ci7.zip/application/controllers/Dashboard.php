<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
 function __construct() {
  parent::__construct();

  $this->load->model('m_sdpa');
  $this->auth->cek_auth();
  $this->load->helper(array('form', 'url'));
}


function index() {
  $ambil_akun = $this->m_sdpa->ambil_user($this->session->userdata('u_id'));

  $this->load->library('user_agent');

  $stat = $this->session->userdata('lvl');

  if ($stat=="admin"){

    $this->template->load('vtemplate','sdpa_bl/hello');

  } else {

    echo "user";
    echo "<a href='".base_url()."index.php/dashboard/logout"."'> logout</a>";

  }
}

function login() {
  $session = $this->session->userdata('isLogin');

  if($session == FALSE) {

    $this->load->view('sdpa_bl/login.php');

  } else {

    redirect('dashboard');

  }
}

function logout() {

  $this->session->sess_destroy();
  redirect('login','refresh');

}

public function master_siswa() {

  $data = $this->m_sdpa->getMahasiswa();
  $this->template->load('vtemplate','sdpa_bl/v_lihat_siswa', array('isi' => $data));

}

public function master_guru() {

  $data = $this->m_sdpa->get_data_guru();
  $this->template->load('vtemplate','sdpa_bl/v_lihat_guru', array('isi' => $data));

}

public function master_kelas() {

  $data = $this->m_sdpa->get_data_kelas();
  $this->template->load('vtemplate','sdpa_bl/v_lihat_kelas', array('isi' => $data));

}

public function master_mapel() {

  $data = $this->m_sdpa->get_data_mapel();
  $this->template->load('vtemplate','sdpa_bl/v_lihat_mapel', array('isi' => $data));

}

public function master_peserta() {

  $data = $this->m_sdpa->get_data_peserta();
  $this->template->load('vtemplate','sdpa_bl/v_lihat_peserta', array('isi' => $data));

}

public function addData() {

  echo "<h2>Tambah data</h2>";
  $this->load->view('form_add');

}

public function do_insert_siswa() {

  $data_insert= array(
    'nim'   => $_POST['nim'],
    'nama'  => $_POST['nama'],
    'alamat'=> $_POST['alamat']
    );

  $res = $this->m_sdpa->insertData('mahasiswa', $data_insert);

  if ($res >= 1) {

    $this->session->set_flashdata('pesan', 'Tambah data sukses!');
    redirect("dashboard/master_siswa");

  } else {

    echo "Insert data gagal";

  }
} 

public function do_insert_guru() {

  $this->load->library('upload');
  $nmfile                   = "file_".time();
  $config['upload_path']    = './assets/uploads/';
  $config['allowed_types']  = 'gif|jpg|png';
  $config['max_size']       = 2048;
  $config['max_width']      = 1024;
  $config['max_height']     = 768;
  $config['file_name']      = $nmfile;

  $this->upload->initialize($config);
  $this->upload->do_upload('foto');

  $gbr  = $this->upload->data();
  $foto = base_url()."assets/uploads/".$gbr['file_name'];

  $data_insert = array(
    'employee_id'       => $_POST['employee_id'],   'NIP'               => $_POST['nip'],
    'NUPTK'             => $_POST['nuptk'],         'nama_guru'         => $_POST['nama'],
    'tempat_lahir'      => $_POST['tmpt_lhr'],      'tanggal_lahir'     => $_POST['tgl_lhr'],
    'jenis_kelamin'     => $_POST['jenkel'],        'alamat'            => $_POST['alamat'],
    'agama'             => $_POST['agama'],         'kewarganegaraan'   => $_POST['kwngrn'],
    'warga_negara'      => $_POST['wrg_ngr'],       'status_anak'       => $_POST['stat_anak'],
    'anak_ke'           => $_POST['anak_ke'],       'status_pernikahan' => $_POST['stat_nikah'],
    'tahun_menikah'     => $_POST['thn_mnkh'],      'telp_rumah'        => $_POST['telp_rmh'],
    'no_hp'             => $_POST['no_hp'],         'email'             => $_POST['email'],
    'jml_saudara'       => $_POST['jml_sdr'],       'thn_mulai_tugas'   => $_POST['thn_tgs'],
    'no_sk_dinas'       => $_POST['no_sk_dns'],     'tgl_sk_dinas'      => $_POST['tgl_sk_dns'],
    'bdg_studi_ajar'    => $_POST['b_studi_ajar'],  'mutasi_dari'       => $_POST['mutasi_dari'],
    'no_sk_mutasi'      => $_POST['no_sk_mutasi'],  'stat_karyawan'     => $_POST['stat_kar'],
    'gol_darah'         => $_POST['gol_dar'],       'foto'              => $foto, //$_POST['foto'],
    'tempat_bekerja'    => $_POST['tmpt_krj'],      'jabatan'           => $_POST['jbtn'],
    'pangkat_golongan'  => $_POST['pgkt_gol'],      'stat_pegawai'      => $_POST['stat_pegawai'],
    'mengajar_dikelas'  => $_POST['mgjr_kls'],      'tugas_tambahan'    => $_POST['tgs_tmbhn'],
    'tgkt_jnjg_pddkn'   => $_POST['pddk_terakhir'], 'thn_msk_pddkn'     => $_POST['thn_msk_pddk'],
    'thn_lulus_pddkn'   => $_POST['thn_lls_pddk'],  'nama_bapak'        => $_POST['nm_bpk'],
    'nama_ibu'          => $_POST['nm_ibu'],        'nama_suami'        => $_POST['nm_sm'],
    'nama_istri'        => $_POST['nm_is'],         'tinggi_badan'      => $_POST['tg_bdn'],
    'berat_badan'       => $_POST['brt_bdn'],       'wajah'             => $_POST['wajah'],
    'rambut'            => $_POST['rambut'],        'pykt_derita'       => $_POST['riw_pykt']
    );

  $res = $this->m_sdpa->insert_data_guru('guru', $data_insert);

  if ($res >= 1) {

    $this->session->set_flashdata('pesan', 'Tambah data sukses!');
    redirect("dashboard/master_guru");

  } else {

    echo "Insert data gagal";

  }
}

public function do_edit_guru() {
  $this->load->library('upload');
  $nmfile                   = "file_".time();
  $config['upload_path']    = './assets/uploads/';
  $config['allowed_types']  = 'gif|jpg|png';
  $config['max_size']       = 2048;
  $config['max_width']      = 1024;
  $config['max_height']     = 768;
  $config['file_name']      = $nmfile;

  $this->upload->initialize($config);
  $this->upload->do_upload('foto');

  $gbr  = $this->upload->data();
  $foto = base_url()."assets/uploads/".$gbr['file_name'];

  $data_update = array(
    'employee_id'       => $_POST['employee_id'],   'NIP'               => $_POST['nip'],
    'NUPTK'             => $_POST['nuptk'],         'nama_guru'         => $_POST['nama'],
    'tempat_lahir'      => $_POST['tmpt_lhr'],      'tanggal_lahir'     => $_POST['tgl_lhr'],
    'jenis_kelamin'     => $_POST['jenkel'],        'alamat'            => $_POST['alamat'],
    'agama'             => $_POST['agama'],         'kewarganegaraan'   => $_POST['kwngrn'],
    'warga_negara'      => $_POST['wrg_ngr'],       'status_anak'       => $_POST['stat_anak'],
    'anak_ke'           => $_POST['anak_ke'],       'status_pernikahan' => $_POST['stat_nikah'],
    'tahun_menikah'     => $_POST['thn_mnkh'],      'telp_rumah'        => $_POST['telp_rmh'],
    'no_hp'             => $_POST['no_hp'],         'email'             => $_POST['email'],
    'jml_saudara'       => $_POST['jml_sdr'],       'thn_mulai_tugas'   => $_POST['thn_tgs'],
    'no_sk_dinas'       => $_POST['no_sk_dns'],     'tgl_sk_dinas'      => $_POST['tgl_sk_dns'],
    'bdg_studi_ajar'    => $_POST['b_studi_ajar'],  'mutasi_dari'       => $_POST['mutasi_dari'],
    'no_sk_mutasi'      => $_POST['no_sk_mutasi'],  'stat_karyawan'     => $_POST['stat_kar'],
    'gol_darah'         => $_POST['gol_dar'],       'foto'              => $foto,
    'tempat_bekerja'    => $_POST['tmpt_krj'],      'jabatan'           => $_POST['jbtn'],
    'pangkat_golongan'  => $_POST['pgkt_gol'],      'stat_pegawai'      => $_POST['stat_pegawai'],
    'mengajar_dikelas'  => $_POST['mgjr_kls'],      'tugas_tambahan'    => $_POST['tgs_tmbhn'],
    'tgkt_jnjg_pddkn'   => $_POST['pddk_terakhir'], 'thn_msk_pddkn'     => $_POST['thn_msk_pddk'],
    'thn_lulus_pddkn'   => $_POST['thn_lls_pddk'],  'nama_bapak'        => $_POST['nm_bpk'],
    'nama_ibu'          => $_POST['nm_ibu'],        'nama_suami'        => $_POST['nm_sm'],
    'nama_istri'        => $_POST['nm_is'],         'tinggi_badan'      => $_POST['tg_bdn'],
    'berat_badan'       => $_POST['brt_bdn'],       'wajah'             => $_POST['wajah'],
    'rambut'            => $_POST['rambut'],        'pykt_derita'       => $_POST['riw_pykt']
    );

  $res = $this->m_sdpa->update_data_guru('guru', $data_update, array('employee_id' => $_POST['employee_id']) );

  if ($res >= 1) {

    $this->session->set_flashdata('pesan', 'Update data sukses!');
    redirect("dashboard/master_guru");

  } else {

    echo "Update data gagal";

  }
}

public function do_delete_guru($employee_id)
  {
    $res = $this->m_sdpa->delete_data_guru('guru', array('employee_id' => $employee_id));

    if ($res >= 1) {

      $this->session->set_flashdata('pesan', 'Delete data sukses!');
      redirect("dashboard/master_guru");

    } else {

      echo "Delete data gagal";

    }
  }

public function do_insert_kelas() {

  $data_insert = array(
    'kd_kelas'  => $_POST['kd_kelas'],
    'nm_kelas'  => $_POST['nm_kelas'],
    'kapasitas' => $_POST['kapasitas']
    );

  $res = $this->m_sdpa->insert_data_kelas('kelas', $data_insert);

  if ($res >= 1) {

    $this->session->set_flashdata('pesan', 'Tambah data sukses!');
    redirect("dashboard/master_kelas");

  } else {

    echo "Insert data gagal";

  }
}

public function do_edit_kelas() {
  $data_update= array(
    'kd_kelas'  => $_POST['kd_kelas'],
    'nm_kelas'  => $_POST['nm_kelas'],
    'kapasitas' => $_POST['kapasitas']
    );

  $res = $this->m_sdpa->update_data_kelas('kelas', $data_update, array('kd_kelas' => $_POST['kd_kelas']) );

  if ($res >= 1) {

    $this->session->set_flashdata('pesan', 'Update data sukses!');
    redirect("dashboard/master_kelas");

  } else {

    echo "Update data gagal";

  }
}

public function do_delete_kelas($kd_kelas)
  {
    $res = $this->m_sdpa->delete_data_kelas('kelas', array('kd_kelas' => $kd_kelas));

    if ($res >= 1) {

      $this->session->set_flashdata('pesan', 'Delete data sukses!');
      redirect("dashboard/master_kelas");

    } else {

      echo "Delete data gagal";

    }
  }

public function do_insert_mapel() {

  $data_insert = array(
    'kd_mapel'  => $_POST['kd_mapel'],
    'nm_mapel'  => $_POST['nm_mapel'],
    'kkm'       => $_POST['kkm']
    );

  $res = $this->m_sdpa->insert_data_mapel('mapel', $data_insert);

  if ($res >= 1) {

    $this->session->set_flashdata('pesan', 'Tambah data sukses!');
    redirect("dashboard/master_mapel");

  } else {

    echo "Insert data gagal";

  }
}

public function do_edit_mapel() {
  $data_update= array(
    'kd_mapel'  => $_POST['kd_mapel'],
    'nm_mapel'  => $_POST['nm_mapel'],
    'kkm'       => $_POST['kkm']
    );

  $res = $this->m_sdpa->update_data_mapel('mapel', $data_update, array('kd_mapel' => $_POST['kd_mapel']) );

  if ($res >= 1) {

    $this->session->set_flashdata('pesan', 'Update data sukses!');
    redirect("dashboard/master_mapel");

  } else {

    echo "Update data gagal";

  }
}

public function do_delete_mapel($kd_mapel)
  {
    $res = $this->m_sdpa->delete_data_mapel('mapel', array('kd_mapel' => $kd_mapel));

    if ($res >= 1) {

      $this->session->set_flashdata('pesan', 'Delete data sukses!');
      redirect("dashboard/master_mapel");

    } else {

      echo "Delete data gagal";

    }
  }

public function do_insert_peserta() {

  $data_insert = array(
    'nis'       => $_POST['nis'],
    'kd_kelas'  => $_POST['kd_kelas'],
    'thn_ajar'  => $_POST['thn_ajar']
    );

  $res = $this->m_sdpa->insert_data_peserta('peserta', $data_insert);

  if ($res >= 1) {

    $this->session->set_flashdata('pesan', 'Tambah data sukses!');
    redirect("dashboard/master_peserta");

  } else {

    echo "Insert data gagal";

  }
}

public function do_edit_peserta() {
  $data_update= array(
    'nis'       => $_POST['nis'],
    'kd_kelas'  => $_POST['kd_kelas'],
    'thn_ajar'  => $_POST['thn_ajar']
    );

  $res = $this->m_sdpa->update_data_peserta('peserta', $data_update, array('nis' => $_POST['nis']) );

  if ($res >= 1) {

    $this->session->set_flashdata('pesan', 'Update data sukses!');
    redirect("dashboard/master_peserta");

  } else {

    echo "Update data gagal";

  }
}

public function do_delete_peserta($nis)
  {
    $res = $this->m_sdpa->delete_data_peserta('peserta', array('nis' => $nis));

    if ($res >= 1) {

      $this->session->set_flashdata('pesan', 'Delete data sukses!');
      redirect("dashboard/master_peserta");

    } else {

      echo "Delete data gagal";

    }
  }

function do_upload()
{
  if($this->input->post('upload'))
  {
    $config['upload_path'] = './uploads/';
    $config['allowed_types'] = 'gif|jpg|png';
    $config['max_size']    = '1024';
    $config['max_width']  = '1024';
    $config['max_height']  = '768';
    $this->load->library('upload', $config);
    if ( ! $this->upload->do_upload())
    {
      $error = array('error' => $this->upload->display_errors());
      $this->load->view('upload_form', $error);
    }
    else
    {
      $data=$this->upload->data();
      $this->thumb($data);
      $file=array(
        'img_name'=>$data['raw_name'],
        'thumb_name'=>$data['raw_name'].'_thumb',
        'ext'=>$data['file_ext'],
        'upload_date'=>time()
        );
      $this->upload_model->add_image($file);
      $data = array('upload_data' => $this->upload->data());
      $this->load->view('upload_success', $data);
    }
  }
  else
  {
    redirect(site_url('upload'));
  }
}


public function doEdit($nim) {
  $mhs        = $this->m_sdpa->getMahasiswa("where nim = '$nim' ");
  $data       = array(
    'nim'   => $mhs[0]['nim'],
    'nama'  => $mhs[0]['nama'],
    'alamat'=> $mhs[0]['alamat']
    );

  $this->load->view('form_edit', $data);
}

public function doUpdate() {
  $nim        = $_POST['nim'];
  $nama       = $_POST['nama'];
  $alamat     = $_POST['alamat'];

  $data_update= array(
    'nim' => $nim,
    'nama'  => $nama,
    'alamat'=> $alamat
    );

  $res = $this->m_sdpa->updateData('mahasiswa', $data_update, array('nim' =>$nim));

  if ($res >= 1) {

    $this->session->set_flashdata('pesan', 'Update data sukses!');
    redirect("dashboard/master_siswa");

  } else {

    echo "Update data gagal";

  }
}

public function doDelete($nim) {
  $res = $this->m_sdpa->deleteData('mahasiswa', array('nim' => $nim));

  if ($res >= 1) {

    $this->session->set_flashdata('pesan', 'Delete data sukses!');
    redirect("dashboard/master_siswa");

  } else {

    echo "Delete data gagal";

  }
}
}