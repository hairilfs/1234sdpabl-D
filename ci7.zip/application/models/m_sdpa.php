<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_sdpa extends CI_Model {

	var $tbl_mhs = 'mahasiswa';
	var $tbl_ktgr= 'kategori';
	var $konten  = 'konten';

	function cek_user($nip="", $password="") {

		$query = $this->db->get_where('user', array('id_user' => $nip, 'password' => $password));
		$query = $query->result_array();

		return $query;
	}
	
	function ambil_user($id) {

	    $query = $this->db->get_where('user', array('id_user' => $id));
	    $query = $query->result_array();
	    
	    if($query) {

	        return $query[0];

	    }

  	}

  	public function update_login($data, $where) {
		
		$res = $this->db->update('user', $data, $where);

		return $res;

	}

	public function getKonten($where = "") {

		$data = $this->db->query('select * from konten '.$where);
		return $data;

	}

	public function insertData($namaTable, $data) {

		$res = $this->db->insert($namaTable, $data);

		return $res;

	}

	public function getKategori($where = "") {
		$data = $this->db->query('select * from kategori '.$where);
		return $data;
	}

	public function getMahasiswa($where = "") {
		$data = $this->db->query('select * from mahasiswa '.$where);
		return $data->result_array();
	}


	// ambil data guru
	public function get_data_guru($where = "") {
		$data = $this->db->query('select * from guru '.$where);
		return $data->result_array();
	}

	public function insert_data_guru($namaTable, $data) {
		$res = $this->db->insert($namaTable, $data);
		return $res;
	}

	public function update_data_guru($namaTable, $data, $where) {
		$res = $this->db->update($namaTable, $data, $where);
		return $res;
	}

	public function delete_data_guru($namaTable, $where) {
		$res = $this->db->delete($namaTable, $where);
		return $res;
	}

	// ambil data kelas
	public function get_data_kelas($where = "") {
		$data = $this->db->query('select * from kelas '.$where);
		return $data->result_array();
	}

	public function insert_data_kelas($namaTable, $data) {
		$res = $this->db->insert($namaTable, $data);
		return $res;
	}

	public function update_data_kelas($namaTable, $data, $where) {
		$res = $this->db->update($namaTable, $data, $where);
		return $res;
	}

	public function delete_data_kelas($namaTable, $where) {
		$res = $this->db->delete($namaTable, $where);
		return $res;
	}

	// ambil data mapel
	public function get_data_mapel($where = "") {
		$data = $this->db->query('select * from mapel '.$where);
		return $data->result_array();
	}

	public function insert_data_mapel($namaTable, $data) {
		$res = $this->db->insert($namaTable, $data);
		return $res;
	}

	public function update_data_mapel($namaTable, $data, $where) {
		$res = $this->db->update($namaTable, $data, $where);
		return $res;
	}

	public function delete_data_mapel($namaTable, $where) {
		$res = $this->db->delete($namaTable, $where);
		return $res;
	}

	// ambil data peserta
	public function get_data_peserta($where = "") {
		$data = $this->db->query('select * from peserta '.$where);
		return $data->result_array();
	}

	public function insert_data_peserta($namaTable, $data) {
		$res = $this->db->insert($namaTable, $data);
		return $res;
	}

	public function update_data_peserta($namaTable, $data, $where) {
		$res = $this->db->update($namaTable, $data, $where);
		return $res;
	}

	public function delete_data_peserta($namaTable, $where) {
		$res = $this->db->delete($namaTable, $where);
		return $res;
	}


	public function updateData($namaTable, $data, $where) {

		$res = $this->db->update($namaTable, $data, $where);

		return $res;

	}

	public function deleteData($namaTable, $where) {

		$res = $this->db->delete($namaTable, $where);

		return $res;

	}

}
