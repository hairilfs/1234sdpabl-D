<div class="jumbotron">
    <h1>Hello, admin!</h1>
    <p>This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
</div>