<button type="button" class="btn btn-success" data-toggle="modal" data-target="#add-peserta"><i class="fa fa-plus"></i> Tambah Data</button> 

<table id="example" class="table table-striped responsive-utilities jambo_table">
  <thead>
    <tr class="headings">
            <!-- <th>
                <input type="checkbox" class="tableflat">
              </th> -->
              <th>No. </th>
              <th>NIS </th>
              <th>Kode Kelas </th>
              <th>Tahun Ajar </th>
              <th class="no-link last" style='text-align:center;'>
                <span class="nobr">Action</span>
              </th>
            </tr>
          </thead>

          <tbody>
            <?php
            $no = 1;
            foreach ($isi as $key) { 
              ?>  

              <tr class="even pointer">
            <!-- <td class="a-center ">
                <input type="checkbox" class="tableflat">
              </td> -->

              <td><?= $no++ ?></td>
              <td><?= $key['nis']; ?></td>
              <td><?= $key['kd_kelas']; ?></td>
              <td><?= $key['thn_ajar']; ?></td>

              <td align="center">
                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#detil-peserta<?= $key['nis']; ?>"><i class="fa fa-th-list"></i> Detil</button>
                <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#edit-peserta<?= $key['nis']; ?>"><i class="fa fa-edit"></i> Ubah</a>
                  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete-peserta<?= $key['nis']; ?>"><i class="fa fa-trash"></i> Hapus</a>
                  </td>
                </tr>

                <div class="modal fade bs-example-modal" id="delete-peserta<?= $key['nis']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">

                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                        </button>
                        <h4 class="modal-title" id="myModalLabel2">Hapus Data Peserta</h4>
                      </div>
                      <div class="modal-body">
                        <p align="center">Apakah anda yakin ingin menghapus data <?= $key['nis']; ?>?</p>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                        <a href="<?= base_url().'dashboard/do_delete_peserta/'.$key['nis']; ?>" type="button" class="btn btn-danger">Ya, Hapus</a>
                        <!-- <button type="button" >/button> -->
                      </div>

                    </div>
                  </div>
                </div>

                <div class="modal fade bs-example-modal-lg" id="edit-peserta<?= $key['nis']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                      <!-- modal header -->
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <h3 class="modal-title" id="myModalLabel2">Ubah Data Peserta</h3>
                      </div>
                      <form class="form-horizontal form-label-left" action="<?= base_url(); ?>dashboard/do_edit_peserta" method="post" enctype="multipart/form-data">
                        <!-- modal body -->
                        <div class="modal-body">
                          <div class="" role="tabpanel" data-example-id="togglable-tabs">
                            <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                              <li role="presentation" class="active"><a href="#tab_content1_edit<?= $key['nis']; ?>" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Data 1</a>
                              </li>
                              <li role="presentation" class=""><a href="#tab_content2_edit<?= $key['nis']; ?>" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Data 2</a>
                              </li>
                              <li role="presentation" class=""><a href="#tab_content3_edit<?= $key['nis']; ?>" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Data 3</a>
                              </li>
                            </ul>
                            <div id="myTabContent" class="tab-content">
                              <!-- tab panel ke 1 -->
                              <div role="tabpanel" class="tab-pane fade active in" id="tab_content1_edit<?= $key['nis']; ?>" aria-labelledby="home-tab">
                                <div class="row">
                                  <div class="col-md-6">
                                    <div class="form-group">
                                      <label class="control-label col-md-4 col-sm-3 col-xs-12">NIS</label>
                                      <div class="col-md-8 col-sm-9 col-xs-12">
                                        <input name="nis" type="text" class="form-control" value="<?= $key['nis']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label class="control-label col-md-4 col-sm-3 col-xs-12">Kode Kelas</label>
                                      <div class="col-md-8 col-sm-9 col-xs-12">
                                        <input name="kd_kelas" type="text" class="form-control" value="<?= $key['kd_kelas']; ?>">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label class="control-label col-md-4 col-sm-3 col-xs-12">Tahun Ajar</label>
                                      <div class="col-md-8 col-sm-9 col-xs-12">
                                        <input name="thn_ajar" type="text" class="form-control" value="<?= $key['thn_ajar']; ?>">
                                      </div>
                                    </div>
                                    
                                  </div>

                                  <div class="col-md-6">

                                  </div>
                                </div>
                              </div>

                              <!-- tab panel ke 2 -->
                              <div role="tabpanel" class="tab-pane fade" id="tab_content2_edit<?= $key['nis']; ?>" aria-labelledby="profile-tab">
                                <div class="row">
                                  <div class="col-md-6">
                                    
                                  </div>

                                  <div class="col-md-6">
                                    
                                  </div>
                                </div>
                              </div>

                              <!-- tab panel ke 3 -->
                              <div role="tabpanel" class="tab-pane fade" id="tab_content3_edit<?= $key['nis']; ?>" aria-labelledby="profile-tab">
                                <div class="row">
                                  <div class="col-md-6">
                                    
                                  </div>

                                  <div class="col-md-6">

                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>                    
                        <!-- modal footer -->
                        <div class="modal-footer ">
                          <div class="pull-right">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>

                <div class="modal fade bs-example-modal-lg" id="detil-peserta<?= $key['nis']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                      <!-- modal header -->
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <h3 class="modal-title" id="myModalLabel2">Detil Data Peserta</h3>
                      </div>
                      <!-- modal body -->
                      <div class="modal-body">
                        <div class="row">
                          <div class="col-md-3 col-sm-3 col-xs-12 profile_left">

                            <img width="250px" src="<?= base_url();?>assets/images/user.png" class="img-thumbnail" alt="Avatar">

                            <h3 style="text-align: center;"><?= $key['nis']; ?></h3>
                            <h4><i class="fa fa-key"></i> Emp. ID : <?= $key['nis']; ?></h4>
                            <br>
                            <!-- start skills -->
                            <h4><u>Main Profile</u></h4>
                            <ul class="list-unstyled user_data">
                              <li><i class="fa fa-birthday-cake"></i> </li>
                              <li><i class="fa fa-user"></i> </li>
                              <li><i class="fa fa-star"></i> </li>
                              <li><i class="fa fa-phone"></i> </li>
                              <li><i class="fa fa-envelope"></i> </li>
                              <li><i class="fa fa-briefcase"></i> </li>
                            </ul>
                            <!-- end of skills -->
                          </div>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                            <div class="" role="tabpanel" data-example-id="togglable-tabs">
                              <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#tab_content1_detil<?= $key['nis']; ?>" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Data 1</a>
                                </li>
                                <li role="presentation" class=""><a href="#tab_content2_detil<?= $key['nis']; ?>" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Data 2</a>
                                </li>
                                <li role="presentation" class=""><a href="#tab_content3_detil<?= $key['nis']; ?>" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Data 3</a>
                                </li>
                              </ul>
                              <div id="myTabContent" class="tab-content">
                                <div role="tabpanel" class="tab-pane fade active in" id="tab_content1_detil<?= $key['nis']; ?>" aria-labelledby="home-tab">
                                  <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                      <div class="dashboard-widget-content">
                                        <ul class="list-unstyled timeline widget">
                                          <li>
                                            <div class="block">
                                              <div class="block_content">
                                                <h2 class="title" style="font-weight: bold;">NIS</h2>
                                                <p class="excerpt"><?= $key['nis']; ?></p>
                                              </div>
                                            </div>
                                          </li>
                                          <li>
                                            <div class="block">
                                              <div class="block_content">
                                                <h2 class="title" style="font-weight: bold;">Kode Kelas</h2>
                                                <p class="excerpt"><?= $key['kd_kelas']; ?></p>
                                              </div>
                                            </div>
                                          </li>
                                          <li>
                                            <div class="block">
                                              <div class="block_content">
                                                <h2 class="title" style="font-weight: bold;">Tahun Ajar</h2>
                                                <p class="excerpt"><?= $key['thn_ajar']; ?></p>
                                              </div>
                                            </div>
                                          </li>
                                          
                                        </ul>
                                      </div>
                                      
                                    </div>

                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                      <div class="dashboard-widget-content">
                                        <ul class="list-unstyled timeline widget">

                                        </ul>
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <div role="tabpanel" class="tab-pane fade" id="tab_content2_detil<?= $key['nis']; ?>" aria-labelledby="profile-tab">
                                  <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                      <div class="dashboard-widget-content">
                                        <ul class="list-unstyled timeline widget">
                                          
                                        </ul>
                                      </div>
                                      
                                    </div>

                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                      <div class="dashboard-widget-content">
                                        <ul class="list-unstyled timeline widget">

                                        </ul>
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <div role="tabpanel" class="tab-pane fade" id="tab_content3_detil<?= $key['nis']; ?>" aria-labelledby="profile-tab">
                                  <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                      <div class="dashboard-widget-content">
                                        <ul class="list-unstyled timeline widget">

                                        </ul>
                                      </div>
                                    </div>

                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                      <div class="dashboard-widget-content">
                                        <ul class="list-unstyled timeline widget">
                                         
                                        </ul>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>                    
                      <!-- modal footer -->
<!--                 <div class="modal-footer ">
                  <div class="pull-right">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Ok</button>
                  </div>
                </div> -->
              </div>
            </div>
          </div>

          <?php   
        } 
        ?>

      </tbody>
    </table>
    <div class="modal fade bs-example-modal-lg" id="add-peserta" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <!-- modal header -->
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            <h3 class="modal-title" id="myModalLabel2">Tambah Data Peserta</h3>
          </div>
          <form class="form-horizontal form-label-left" action="<?= base_url(); ?>dashboard/do_insert_peserta" method="post" enctype="multipart/form-data">
            <!-- modal body -->
            <div class="modal-body">
              <div class="" role="tabpanel" data-example-id="togglable-tabs">
                <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                  <li role="presentation" class="active"><a href="#tab_content1_add" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Data 1</a>
                  </li>
                  <li role="presentation" class=""><a href="#tab_content2_add" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Data 2</a>
                  </li>
                  <li role="presentation" class=""><a href="#tab_content3_add" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Data 3</a>
                  </li>
                </ul>
                <div id="myTabContent" class="tab-content">
                  <!-- tab panel ke 1 -->
                  <div role="tabpanel" class="tab-pane fade active in" id="tab_content1_add" aria-labelledby="home-tab">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12">NIS</label>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                            <input name="nis" type="text" class="form-control">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12">Kode Kelas</label>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                            <input name="kd_kelas" type="text" class="form-control">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12">Tahun Ajar</label>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                            <input name="thn_ajar" type="text" class="form-control">
                          </div>
                        </div>
                       
                      </div>

                      <div class="col-md-6">

                      </div>
                    </div>
                  </div>
                  <!-- tab panel ke 2 -->
                  <div role="tabpanel" class="tab-pane fade" id="tab_content2_add" aria-labelledby="profile-tab">
                    <div class="row">
                      <div class="col-md-6">

                      </div>

                      <div class="col-md-6">
                      </div>
                    </div>
                  </div>
                  <!-- tab panel ke 3 -->
                  <div role="tabpanel" class="tab-pane fade" id="tab_content3_add" aria-labelledby="profile-tab">
                    <div class="row">
                      <div class="col-md-6">

                      </div>

                      <div class="col-md-6">

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>                    
            <!-- modal footer -->
            <div class="modal-footer ">
              <div class="pull-right">
                <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>  